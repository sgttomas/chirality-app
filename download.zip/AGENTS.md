# AGENTS.md — How to use the agent framework in this repo

This file is the operator-facing index and “rules of the road” for using the agents shipped with this repository.

**Naming convention:** use `AGENT_*` when referring to instruction files (e.g., `AGENT_CHANGE.md`); use the role name (e.g., `CHANGE`) when referring to the agent itself. This applies to all agents.

---

## 0) Standards & precedence (canonical spec)

- **Canonical standard:** `AGENT_HELPS_HUMANS.md`. Where any other `AGENT_*` file disagrees, **the other file must be edited to conform**.
- **Required metadata:** every `AGENT_*` instruction file should include the canonical Agent Header Block fields (e.g., `AGENT_CLASS`, `INTERACTION_SURFACE`, `WRITE_SCOPE`, `BLOCKING`, `PRIMARY_OUTPUTS`) and use canonical terminology.
- **Contract discipline:** Type 0 defines/maintains contracts. Type 1 Managers write briefs and orchestrate; Type 2 Specialists execute bounded briefs and return checkable outputs + evidence.
- **Auditing:** use `AUDIT_AGENT.md` as the fill-in rubric when adding agents or checking conformance across the suite.

---

## 1) The core model (the rules that keep the system coherent)

### Project Decomposition
- A project that lacks structure cannot be effectively worked on by agents.
- Project decomposition is what initiates all other agentic workflows.
- **Decomposition invariant:** Projects are always decomposed as **Packages containing Deliverables**.
- Use **PROJECT_DECOMP** to create a decomposition from a messy Scope of Work (SOW).
- The project decomposition file is located here:

`{EXECUTION_ROOT}/_Decomposition/`

### Filesystem is the state
- Project “truth” is what is on disk: folders + `_STATUS.md` + the four documents.
- Agents must not maintain a hidden database or private state that diverges from the filesystem.

### Deliverables (working-items) are local
- A **deliverable** (`DEL-XXX-YY`) is one folder under `{EXECUTION_ROOT}/{PKG-ID}_{PkgLabel}/1_Working/{DEL-ID}_{DelLabel}/`.
- Work inside that folder is **local**: no cross-deliverable “crosstalk” by default.

### Local lifecycle (not stage gates)
Deliverables progress through a local lifecycle:

`OPEN → INITIALIZED → SEMANTIC_READY → IN_PROGRESS → CHECKING → ISSUED`

- **Stage gates** (30/60/90/IFC, etc.) are *human-managed* milestones and are **not** lifecycle states.
- **SEMANTIC_READY** indicates `_SEMANTIC.md` exists (semantic lens). If the lens step is skipped, deliverables may move from `INITIALIZED → IN_PROGRESS` directly.
- `_STATUS.md` is the authoritative lifecycle indicator.

### Cross-deliverable operations are opt-in and human-triggered
- **RECONCILIATION**: coherence checks across a human-defined scope (read-only deliverables) → writes under `execution/_Reconciliation/`.
- **AGGREGATION**: synthesis/collection across a human-defined scope (read-only inputs by default) → writes under `execution/_Aggregation/`.
- **ESTIMATING**: estimate snapshot generation across a defined scope (read-only deliverables) → writes under `execution/_Estimates/`. Runs are parameterized by `BASIS_OF_ESTIMATE` (QUOTE | RATE_TABLE | HISTORICAL | PARAMETRIC | ALLOWANCE). No agent-authored BOE is required by default.
- **SCHEDULING**: parameterized schedule generation from the dependency graph (read-only deliverables) → writes under `execution/_Schedule/`. Supports PRECEDENCE, CONSTRAINT, or HYBRID scheduling basis.

---

## 2) Agent classification (quick reference)

Agents are classified by how they interact, what they write, and whether they can block for human input.

### Classification Properties

| Property | Values | Meaning |
|----------|--------|---------|
| **AGENT_CLASS** | `PERSONA` / `TASK` | Persona agents run interactive sessions; Task agents run pipelines |
| **INTERACTION_SURFACE** | `chat` / `INIT-TASK` / `spawned` / `both` | How the agent is invoked |
| **WRITE_SCOPE** | `project-level` / `tool-root-only` / `deliverable-local` / `none` | What the agent is allowed to write |
| **BLOCKING** | `allowed` / `never` | Whether the agent may pause for human input |

Each agent instruction file also declares **AGENT_TYPE**:
- `0` — intent alignment and operator control (Type 0)
- `1` — interactive orchestration (Type 1)
- `2` — bounded task execution (Type 2)

### Full Agent Type Table

| Agent | CLASS | INTERACTION | PRIMARY_OUTPUTS |
| --- | --- | --- | --- |
| **4_DOCUMENTS** | TASK | spawned | 4 docs, `_STATUS.md` (OPEN→INITIALIZED) |
| **AGGREGATION** | TASK | spawned | Snapshots in `_Aggregation/` |
| **AUDIT_AGENTS** | TASK | spawned | Agent state report |
| **AUDIT_DECOMP** | TASK | spawned | `Decomp-Coverage_Report.md`, `Decomp-Coverage_IssueLog.csv`, `Decomp-Coverage_Matrix.csv`, and `coverage_summary.json` |
| **AUDIT_DEPENDENCIES** | TASK | spawned | Dependencies state report |
| **CHANGE** | PERSONA | chat | Git state report; optional git actions after explicit approval |
| **CHIRALITY_FRAMEWORK** | TASK | spawned | `_SEMANTIC.md`, `_STATUS.md` |
| **CHIRALITY_LENS** | TASK | spawned | `_SEMANTIC_LENSING.md` |
| **DEPENDENCIES** | TASK | spawned | `_DEPENDENCIES.md`, `Dependencies.csv` |
| **ESTIMATING** | TASK | spawned | Estimate snapshots in `_Estimates/` |
| **HELP_HUMAN** | PERSONA | chat | Briefs, checklists, interpretations, next-step recommendations |
| **HELPS_HUMANS** | PERSONA | chat | Workflow design standards; agent instruction maintenance guidance |
| **ORCHESTRATOR** | PERSONA | chat | `_COORDINATION.md`; spawns sub-agents |
| **PREPARATION** | TASK | spawned | Folders, metadata files |
| **PROJECT_CONTROLS** | PERSONA | chat | Project controls register, decision capture, run plans |
| **PROJECT_DECOMP** | PERSONA | chat | Decomposition document |
| **RECONCILIATION** | PERSONA | chat | Reports in `_Reconciliation/` |
| **SCHEDULING** | PERSONA | chat | Schedule structure, duration model, Gantt (Mermaid + CSV), critical path / risk report in `_Schedule/` — parameterized by `BASIS_OF_SCHEDULE` (PRECEDENCE / CONSTRAINT / HYBRID) |
| **TASK_SETUP** | TASK | spawned | Initialized agent instructions specific to the deliverable |
| **WORKING_ITEMS** | PERSONA | chat | User defined output |


---

EOF
